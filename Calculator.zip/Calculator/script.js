const display = document.getElementById("display");
const buttons = document.querySelectorAll(".btn");
const toggleTheme = document.getElementById("toggleTheme");
const historyList = document.getElementById("historyList");

let currentInput = "";
let resetNext = false;

// Theme toggle
toggleTheme.addEventListener("click", () => {
    document.body.classList.toggle("light");
});

// Add to history
function addToHistory(expression, result) {
    const li = document.createElement("li");
    li.textContent = `${expression} = ${result}`;
    historyList.prepend(li); // newest on top
}

// Button functionality
buttons.forEach(button => {
    button.addEventListener("click", () => {
        const value = button.getAttribute("data-value");

        if (value === "C") {
            currentInput = "";
            display.textContent = "0";
        } else if (value === "DEL") {
            if (currentInput.length > 0) {
                currentInput = currentInput.slice(0, -1);
                display.textContent = currentInput || "0";
            }
        } else if (value === "=") {
            try {
                const result = eval(currentInput).toString();
                addToHistory(currentInput, result);
                currentInput = result;
                display.textContent = currentInput;
                resetNext = true;
            } catch {
                display.textContent = "Error";
                currentInput = "";
            }
        } else if (value === "sqrt") {
            const result = Math.sqrt(parseFloat(currentInput)).toString();
            addToHistory(`√(${currentInput})`, result);
            currentInput = result;
            display.textContent = currentInput;
        } else if (value === "%") {
            const result = (parseFloat(currentInput) / 100).toString();
            addToHistory(`${currentInput}%`, result);
            currentInput = result;
            display.textContent = currentInput;
        } else if (value === "^") {
            currentInput += "**"; // exponent operator
            display.textContent = currentInput;
        } else if (value === "sin") {
            const result = Math.sin(parseFloat(currentInput) * Math.PI / 180).toString();
            addToHistory(`sin(${currentInput})`, result);
            currentInput = result;
            display.textContent = currentInput;
        } else if (value === "cos") {
            const result = Math.cos(parseFloat(currentInput) * Math.PI / 180).toString();
            addToHistory(`cos(${currentInput})`, result);
            currentInput = result;
            display.textContent = currentInput;
        } else if (value === "tan") {
            const result = Math.tan(parseFloat(currentInput) * Math.PI / 180).toString();
            addToHistory(`tan(${currentInput})`, result);
            currentInput = result;
            display.textContent = currentInput;
        } else {
            if (resetNext) {
                currentInput = "";
                resetNext = false;
            }
            currentInput += value;
            display.textContent = currentInput;
        }
    });
});
